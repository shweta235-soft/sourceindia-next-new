# SourceIndia Batch 13: Clean Layout and Routing Repair

## Why this package exists
The reported symptoms were: `Missing <html> and <body> tags`, `/` showing Admin Dashboard instead of the public homepage, and duplicate Admin Header/Sidebar.

The provided Batch 13 project source already has a root `src/app/layout.tsx` with `<html>` and `<body>`, `src/app/page.tsx` renders `Homepage`, and `src/app/admin/layout.tsx` mounts `AdminShell` once. Those three symptoms together strongly suggest mixed/leftover route files or a dev server pointed at a different project. The exact state of the user's Windows folder cannot be inspected here.

## Safe installation (no manual code editing)
1. Stop any running `npm run dev` or `npm run build` processes.
2. Extract this ZIP into `E:\nextjs\sourceindia-batch13-repair` (a SEPARATE folder, not inside the target).
3. Run this one PowerShell command:
   `powershell -ExecutionPolicy Bypass -File "E:\nextjs\sourceindia-batch13-repair\apply-repair.ps1"`
4. From `E:\nextjs\sourceindia-next-new`, run `npm run build`, then `npm run dev`.
5. Check `/` for public homepage, `/admin` for dashboard, `/admin/sellers` for one header and sidebar.

The script backs up the previous `src`, `public`, root `app` and `pages` directories outside the target project, and copies clean source. It preserves `.env.local`, `.git`, and `node_modules`. No database, React reference project, or live API is changed.

## Verification limits
ZIP integrity and static route/layout checks were performed. Next.js build and browser rendering could not be run in the current environment because the required npm dependencies were not available locally.
