# Batch 17 — Member table search and selection reliability

- Sellers and Buyers search waits 350 ms after typing before requesting the live API, reducing unnecessary requests.
- Every query change now sets the loading state and clears stale selected row IDs, preventing accidental bulk selection across filtered pages.
- Pagination uses a bounded visible page number.
- Existing routes, layouts, styles, and API endpoint paths are unchanged.
- No database changes or React source modifications.
- ZIP integrity verified; production build and browser tests not executed here.
