Batch 09: React app.css base typography 14px, sidebar 250px, topbar 60px, primary #00449c; overrides for undersized seller/buyer UI. Build and visual parity not verified. No API changes.
