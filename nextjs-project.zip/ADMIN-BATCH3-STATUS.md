Admin Batch 3: Buyer/Seller listing foundation.
Includes search, pagination, sorting, live server-side API and 9 route variants.
Not implemented: React advanced filters, modals, edit/add forms, export, dashboard charts/tables, auth enforcement.
Do not treat these as completed or React-parity pages.
