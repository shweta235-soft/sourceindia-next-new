# Admin Seller Table Refinement

Updated seller listing table to reflect React's company-focused columns, selectable rows, detail fields, date columns, and status labels. Bulk-action buttons are deliberately disabled until their API authorization and behavior are verified. Buyer table remains unchanged. This is a partial parity update, not a complete migration. Build not verified in this environment.
