# Admin UI Batch 03 — Sellers filter layout

Based on original React `frontend/src/admin/pages/SellerList.jsx`, the Sellers filter grid now includes the same named dropdown fields: Core Activities, Activities, Categories, Nature of Business, State, City, Designations, and Elcina Member. They are explicitly disabled until their live lookup APIs are verified; this is UI-only work and does not pretend to offer functional filters. Existing text/date filters and listing API remain unchanged.

This is NOT exact parity: dynamic dropdown options, table field mapping, status actions, Excel and bulk actions are pending. Build was not verified in this environment.
