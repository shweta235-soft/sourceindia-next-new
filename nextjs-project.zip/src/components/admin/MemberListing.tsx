"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import "./react-seller-ui.css";
import { apiFetch } from "@/lib/api";

type Member = Record<string, unknown>;
type Response = { data?: Member[]; totalRecords?: number; filteredRecords?: number };
type LookupOption = { id: string | number; name: string };
const lookupPaths: Record<string, string> = { core_activity:"core_activities?is_delete=0", categoryId:"categories", nature_business:"sellers/nature_business", designation:"sellers/designations", state:"location/states/101" };
const normalizeOptions = (value: unknown): LookupOption[] => { const list = Array.isArray(value) ? value : value && typeof value === "object" && "data" in value && Array.isArray(value.data) ? value.data : []; return list.filter((item): item is LookupOption => Boolean(item && typeof item === "object" && "id" in item && "name" in item)); };
const asText = (value: unknown) => value == null ? "—" : String(value);
const get = (m: Member, ...keys: string[]) => { for (const k of keys) if (m[k] !== undefined && m[k] !== null && m[k] !== "") return asText(m[k]); return "—"; };
export default function MemberListing({ kind, variant = "all" }: { kind: "buyers" | "sellers"; variant?: "all" | "inactive" | "notApproved" | "notCompleted" | "deleted" }) {
  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [draftFilters, setDraftFilters] = useState({customerId:"",fullName:"",firstName:"",lastName:"",organizationName:"",startDate:"",endDate:"",core_activity:"",activity:"",categoryId:"",nature_business:"",state:"",city:"",designation:"",elcina_member:""});
  const [filters, setFilters] = useState(draftFilters);
  const [lookups, setLookups] = useState<Record<string, LookupOption[]>>({});
  useEffect(() => { if (kind !== "sellers") return; let active = true; Object.entries(lookupPaths).forEach(([key,path]) => {apiFetch<unknown>(path).then(data => {if(active) setLookups(old => ({...old,[key]:normalizeOptions(data)}));}).catch(() => {});}); return () => {active=false;}; }, [kind]);
  useEffect(() => { if (kind !== "sellers") return; const id = draftFilters.core_activity; if(!id){setLookups(old=>({...old,activity:[]}));return;} let active=true; apiFetch<unknown>(`activities/coreactivity/${encodeURIComponent(id)}`).then(data=>{if(active)setLookups(old=>({...old,activity:normalizeOptions(data)}));}).catch(()=>{});return ()=>{active=false;};},[kind,draftFilters.core_activity]);
  useEffect(() => { if (kind !== "sellers") return; const id=draftFilters.state; if(!id){setLookups(old=>({...old,city:[]}));return;} let active=true; apiFetch<unknown>(`location/cities/${encodeURIComponent(id)}`).then(data=>{if(active)setLookups(old=>({...old,city:normalizeOptions(data)}));}).catch(()=>{});return ()=>{active=false;};},[kind,draftFilters.state]);
  const [showFilters, setShowFilters] = useState(kind === "sellers");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(25);
  const [sortBy, setSortBy] = useState(kind === "sellers" ? "approve_date" : "id");
  const [sort, setSort] = useState<"ASC" | "DESC">("DESC");
  const [result, setResult] = useState<Response>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const query = useMemo(() => {
    const params = new URLSearchParams({page:String(page),limit:String(limit),search,sortBy,sort,
      getInactive:String(variant === "inactive"),getNotApproved:String(variant === "notApproved"),getDeleted:String(variant === "deleted")});
    if (kind === "sellers") params.set("getNotCompleted", String(variant === "notCompleted"));
    for (const [key, value] of Object.entries(filters)) {
      if (!value.trim()) continue;
      if (kind === "buyers" && ["firstName","lastName","organizationName"].includes(key)) continue;
      if (kind === "sellers" && key === "fullName") continue;
      params.set(key === "fullName" ? "full_name" : key, value.trim());
    }
    return params.toString();
  }, [kind, page, limit, search, sortBy, sort, variant, filters]);
  useEffect(() => {
    let cancelled = false;
    apiFetch<Response>(`${kind}/server-side?${query}`)
      .then((response) => { if (!cancelled) {setResult(response);setError("");} })
      .catch((e: unknown) => { if (!cancelled) {setError(e instanceof Error ? e.message : "Unable to load records");setResult({});} })
      .finally(() => {if (!cancelled) setLoading(false);});
    return () => {cancelled = true;};
  }, [kind, query]);
  const records = Array.isArray(result.data) ? result.data : [];
  const total = Number(result.filteredRecords ?? result.totalRecords ?? 0);
  const title = `${variant === "all" ? "" : variant === "notApproved" ? "Not Approved " : variant === "notCompleted" ? "Not Completed " : variant.charAt(0).toUpperCase()+variant.slice(1)+" "}${kind === "buyers" ? "Buyers" : "Sellers"}`;
  const pageCount = Math.max(1, Math.ceil(total / limit));
  const pageNumbers = Array.from({length: Math.min(5, pageCount)}, (_, i) => Math.max(1, Math.min(pageCount - 4, page - 2)) + i);
  const sortColumn = (field: string) => {setPage(1);if(sortBy===field)setSort(sort === "ASC" ? "DESC" : "ASC");else {setSortBy(field);setSort("ASC");}};
  return <div className={kind === "sellers" ? "admin-sellers-parity" : ""} style={{padding:"12px 16px",fontSize:14}}>
    <nav style={{marginBottom:12,fontSize:14}}><Link href="/admin">Dashboard</Link> / {title}</nav>
    <div className="seller-page-heading" style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12,marginBottom:12}}><h1 style={{fontSize:20,fontWeight:700,margin:0}}>{kind === "sellers" && variant === "all" ? "Sellers List" : title} {kind === "sellers" && <small style={{fontSize:13,color:"#00449c"}}>{total}</small>}</h1><Link href={`/admin/add_${kind === "buyers" ? "buyer" : "seller"}`} style={{background:"#00449c",color:"white",padding:"10px 16px",borderRadius:5}}>Add {kind === "buyers" ? "Buyer" : "Seller"}</Link></div>
    {kind === "sellers" && <div className="seller-actions react-seller-actions" style={{display:"flex",gap:5,justifyContent:"flex-end",flexWrap:"wrap",marginBottom:8}}>
      {(["Selected Mail","All Mail","Excel","Delete Selected"] as const).map(label=><button key={label} type="button" disabled title="Requires API and permission verification" style={{fontSize:13,padding:"8px 12px",border:0,borderRadius:3,background:label==="Delete Selected"?"#dc3545":"#00449c",color:"white",opacity:.65,cursor:"not-allowed"}}>{label}</button>)}
    </div>}
    <div className="admin-member-listing-card" style={{background:"white",border:"1px solid #e5e9ef",borderRadius:4,padding:12}}>
      {kind !== "sellers" && <div style={{marginBottom:14}}><button type="button" onClick={()=>setShowFilters(v=>!v)} aria-expanded={showFilters} style={{border:"1px solid #00449c",color:"#00449c",background:"white",borderRadius:4,padding:"8px 14px"}}>{showFilters ? "Hide Filters" : "Advanced Filters"}</button></div>}
      {showFilters && <form onSubmit={e=>{e.preventDefault();setFilters({...draftFilters});setPage(1);setLoading(true);}} className="seller-filter-grid react-admin-filter-grid" style={{display:"grid",gridTemplateColumns:"repeat(4,minmax(0,1fr))",gap:12,background:"#fff",padding:16,marginBottom:16,borderRadius:4}}>
        {([ ["customerId","Customer ID"],...(kind === "buyers" ? [["fullName","Full Name"]] : [["firstName","First Name"],["lastName","Last Name"],["organizationName","Company"]]),["startDate","Start Date"],["endDate","End Date"]] as string[][]).map(([key,label])=><label key={key} style={{display:"grid",gap:5,fontSize:13}}>{label}<input type={key.endsWith("Date")?"date":"text"} value={draftFilters[key as keyof typeof draftFilters]} onChange={e=>setDraftFilters(prev=>({...prev,[key]:e.target.value}))} style={{padding:8,border:"1px solid #ccd3dd",borderRadius:4}} /></label>)}
        {kind === "sellers" && ([ ["core_activity","Core Activities"], ["activity","Activities"], ["categoryId","Categories"], ["nature_business","Nature of Business"], ["state","State"], ["city","City"], ["designation","Designations"], ["elcina_member","Elcina Member"] ] as const).map(([key,label]) => (
          <label key={key} style={{display:"grid",gap:5,fontSize:14,color:"#343a40"}}>{label}
            <select aria-label={label} value={draftFilters[key]} onChange={e=>setDraftFilters(prev=>({...prev,[key]:e.target.value,...(key==="core_activity"?{activity:""}:{}),...(key==="state"?{city:""}:{})}))} style={{padding:8,border:"1px solid #ccd3dd",borderRadius:4,background:"#fff"}}>
              <option value="">{key === "elcina_member" ? "-- Select --" : "All"}</option>
              {(key === "elcina_member" ? [{id:1,name:"Yes"},{id:2,name:"No"},{id:3,name:"Not Sure"}] : lookups[key] || []).map(option=><option key={option.id} value={key === "designation" ? option.name : option.id}>{option.name}</option>)}
            </select>
          </label>
        ))}
        <div style={{display:"flex",gap:8,alignItems:"end"}}><button type="submit" style={{background:"#00449c",color:"white",border:0,padding:"9px 15px",borderRadius:4}}>Apply</button><button type="button" onClick={()=>{const empty={customerId:"",fullName:"",firstName:"",lastName:"",organizationName:"",startDate:"",endDate:"",core_activity:"",activity:"",categoryId:"",nature_business:"",state:"",city:"",designation:"",elcina_member:""};setDraftFilters(empty);setFilters(empty);setPage(1);setLoading(true);}} style={{border:"1px solid #aaa",padding:"9px 15px",borderRadius:4}}>Clear</button></div>
      </form>}
      <div style={{display:"flex",gap:12,flexWrap:"wrap",justifyContent:"space-between",marginBottom:16}}><label>Show <select value={limit} onChange={e=>{setLimit(Number(e.target.value));setPage(1);}}>{[10,25,50,100].map(n=><option key={n} value={n}>{n}</option>)}</select> entries</label><label>Search: <input aria-label="Search members" value={search} onChange={e=>{setSearch(e.target.value);setPage(1);setLoading(true);}} style={{padding:7,border:"1px solid #ccc",borderRadius:4}} /></label></div>
      {error && <p role="alert" style={{color:"#a11"}}>Unable to load {kind}: {error}. Please verify the live API and access permissions.</p>}
      
      <div className="seller-table-scroll react-admin-table-scroll" style={{overflowX:"auto"}}><table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}>
        {kind === "sellers" ? <>
          <thead><tr style={{background:"#f4f6f9"}}>{["Select","S.No.","Company","Coreactivity / Category / Segment / Sub Segment","Designation / Website / Quality Certification","Created","Last Update","Approve Date","Status","Action"].map((label,i)=><th key={label} style={{padding:"8px 5px",textAlign:"left",borderBottom:"1px solid #ddd",minWidth:i===2?175:undefined}}>{i===0?<input aria-label="Select all sellers on page" type="checkbox" checked={records.length>0&&records.every(m=>selectedIds.includes(get(m,"id","user_id")))} onChange={e=>setSelectedIds(e.target.checked?records.map(m=>get(m,"id","user_id")):[])}/>:label}</th>)}</tr></thead>
          <tbody>{records.map((m,i)=>{const id=get(m,"id","user_id");return <tr key={id+"-"+i} style={{verticalAlign:"top"}}>
            <td style={{padding:6,borderBottom:"1px solid #eee"}}><input aria-label={`Select seller ${id}`} type="checkbox" checked={selectedIds.includes(id)} onChange={e=>setSelectedIds(prev=>e.target.checked?[...prev,id]:prev.filter(v=>v!==id))}/></td>
            <td style={{padding:6,borderBottom:"1px solid #eee"}}><Link href={`/admin/seller/user-profile/${id}`}>{(page-1)*limit+i+1}</Link></td>
            <td style={{padding:6,borderBottom:"1px solid #eee",lineHeight:1.5}}><Link href={`/admin/seller/user-profile/${id}`} style={{fontWeight:700,color:"#00449c"}}>{get(m,"organization_name","company_name")}</Link><div>{get(m,"membership_name","plan_name","membership_type")!=="—"&&<span className="seller-type-badge">{get(m,"membership_name","plan_name","membership_type")}</span>}</div><div>{get(m,"fname","first_name","name")}</div><div>{get(m,"email")}</div><div>{get(m,"mobile","phone","contact_number")}</div><div>{get(m,"city_name","city")} · {get(m,"state_name","state")}</div><div className="seller-products">Products: <span className="seller-product-badge">{get(m,"product_count","products_count","total_products")==="—"?"0":get(m,"product_count","products_count","total_products")}</span></div></td>
            <td style={{padding:6,borderBottom:"1px solid #eee"}}>{get(m,"coreactivity_name","core_activity_name")}<div>{get(m,"category_name","category")}</div><div>{get(m,"segment_name","segment")}</div></td>
            <td style={{padding:6,borderBottom:"1px solid #eee"}}>{get(m,"designation")}<div>{get(m,"website","website_url")}</div><div>{get(m,"quality_certification")}</div></td>
            <td style={{padding:6,borderBottom:"1px solid #eee"}}>{get(m,"created_at","createdAt")}</td><td style={{padding:6,borderBottom:"1px solid #eee"}}>{get(m,"updated_at","updatedAt")}</td><td style={{padding:6,borderBottom:"1px solid #eee"}}>{get(m,"approve_date")}</td>
            <td style={{padding:6,borderBottom:"1px solid #eee"}}><span className={`seller-status-toggle ${get(m,"status")==="1"?"is-on":""}`} role="img" aria-label={get(m,"status")==="1"?"Active":"Inactive"} title="Status display only" /></td>
            <td style={{padding:6,borderBottom:"1px solid #eee"}}><details className="member-row-menu"><summary aria-label={`Actions for seller ${id}`}>⋮</summary><div className="member-row-menu-items"><Link href={`/admin/seller/user-profile/${id}`}>View Profile</Link><button type="button" onClick={() => {if(typeof navigator !== "undefined" && navigator.clipboard && get(m,"email")!=="—") void navigator.clipboard.writeText(get(m,"email"));}}>Copy Email</button></div></details></td>
          </tr>})}{!loading&&!records.length&&<tr><td colSpan={10} style={{padding:22,textAlign:"center"}}>{error?"Records unavailable":"No records found"}</td></tr>}</tbody>
        </> : <>
          <thead><tr style={{background:"#f4f6f9"}}>
            {variant !== "deleted" && <th style={{padding:8}}><input type="checkbox" aria-label="Select all buyers on page" checked={records.length>0&&records.every(m=>selectedIds.includes(get(m,"id","user_id")))} onChange={e=>setSelectedIds(e.target.checked?records.map(m=>get(m,"id","user_id")):[])}/></th>}
            {[["id","S.No."],["user_company","Company"],["address","Location"],...(variant === "deleted" ? [] : [[variant === "notApproved" ? "account_status" : "status",variant === "notApproved" ? "Account Status" : "User Status"],...(variant === "all" ? [["seller_status","Make Seller"]] : [])]),["user_category","User Category"],["created_at","Created"],["updated_at","Last Update"],["action","Action"]].map(([key,label])=><th key={key} style={{padding:8,textAlign:"left",borderBottom:"1px solid #ddd",whiteSpace:"nowrap"}}>{["id","user_company","address","user_category","created_at","updated_at"].includes(key)?<button type="button" onClick={()=>sortColumn(key)} style={{background:"none",border:0,fontWeight:700,cursor:"pointer"}}>{label} {sortBy===key?(sort==="ASC"?"↑":"↓"):""}</button>:label}</th>)}
          </tr></thead>
          <tbody>{records.map((m,i)=>{const id=get(m,"id","user_id");return <tr key={id+"-"+i} style={{verticalAlign:"top"}}>
            {variant !== "deleted" && <td style={{padding:8,borderBottom:"1px solid #eee"}}><input type="checkbox" aria-label={`Select buyer ${id}`} checked={selectedIds.includes(id)} onChange={e=>setSelectedIds(old=>e.target.checked?[...old,id]:old.filter(x=>x!==id))}/></td>}
            <td style={{padding:8,borderBottom:"1px solid #eee"}}><Link href={`/admin/buyer/user-profile/${id}`}>{(page-1)*limit+i+1}</Link></td>
            <td style={{padding:8,borderBottom:"1px solid #eee",lineHeight:1.6,minWidth:180}}><strong>{get(m,"user_company","organization_name","company_name")}</strong><div>{get(m,"full_name","fname","name")}</div><div>{get(m,"email")}</div><div>{get(m,"mobile","phone")}</div>{String(m.is_trading)==="1"&&<span className="badge bg-success me-1">Trader</span>}{String(m.walkin_buyer)==="1"&&<span className="badge bg-primary">Walk-In Buyer</span>}</td>
            <td style={{padding:8,borderBottom:"1px solid #eee"}}>{get(m,"address","full_address")}<div>{get(m,"city_name","city")}</div><div>{get(m,"state_name","state")}</div></td>
            {variant !== "deleted" && <><td style={{padding:8,borderBottom:"1px solid #eee"}}><span className={`seller-status-toggle ${String(m.status)==="1"?"is-on":""}`} role="img" aria-label={String(m.status)==="1"?"Active":"Inactive"} title="Status display only" /></td>{variant === "all"&&<td style={{padding:8,borderBottom:"1px solid #eee"}}><span className={`seller-status-toggle ${String(m.seller_status)==="1"?"is-on":""}`} role="img" aria-label={String(m.seller_status)==="1"?"Seller enabled":"Seller disabled"} title="Seller status display only" /></td>}</>}
            <td style={{padding:8,borderBottom:"1px solid #eee"}}>{get(m,"user_category","category_name","user_category_name")}</td>
            <td style={{padding:8,borderBottom:"1px solid #eee"}}>{get(m,"created_at","createdAt")}</td><td style={{padding:8,borderBottom:"1px solid #eee"}}>{get(m,"updated_at","updatedAt")}</td>
            <td style={{padding:8,borderBottom:"1px solid #eee"}}><details className="member-row-menu"><summary aria-label={`Actions for buyer ${id}`}>⋮</summary><div className="member-row-menu-items"><Link href={`/admin/buyer/user-profile/${id}`}>View Profile</Link><button type="button" onClick={() => {if(typeof navigator !== "undefined" && navigator.clipboard && get(m,"email")!=="—") void navigator.clipboard.writeText(get(m,"email"));}}>Copy Email</button></div></details></td>
          </tr>})}{!loading&&!records.length&&<tr><td colSpan={variant==="deleted"?7:variant==="all"?10:9} style={{padding:22,textAlign:"center"}}>{error?"Records unavailable":"No records found"}</td></tr>}</tbody>
        </>}

      </table></div>
      {loading&&<p role="status">Loading {kind}...</p>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12,marginTop:18}}><span>Showing {records.length ? (page-1)*limit+1 : 0} to {Math.min(page*limit,total)} of {total} entries</span><nav className="admin-list-pagination" aria-label={`${kind} pagination`}><button type="button" disabled={page===1||loading} onClick={()=>{setPage(p=>p-1);setLoading(true);}}>Previous</button>{pageNumbers.map(n=><button key={n} type="button" aria-current={page===n?"page":undefined} disabled={loading} onClick={()=>{setPage(n);setLoading(true);}}>{n}</button>)}<button type="button" disabled={page>=pageCount||loading} onClick={()=>{setPage(p=>p+1);setLoading(true);}}>Next</button></nav></div>
    </div>
  </div>;
}
