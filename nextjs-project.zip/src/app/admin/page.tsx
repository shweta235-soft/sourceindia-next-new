"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { apiFetch } from "@/lib/api";
import styles from "@/components/admin/admin.module.css";

type Counts = Record<string, number | undefined>;
type Endpoint = { key: string; path: string };
const endpoints: Endpoint[] = [
  { key: "sellers", path: "sellers/count" }, { key: "buyers", path: "buyers/count" },
  { key: "categories", path: "categories/count" }, { key: "subCategories", path: "sub_categories/count" },
  { key: "itemCategories", path: "item_category/count" }, { key: "itemSubCategories", path: "item_sub_category/count" },
  { key: "items", path: "items/count" }, { key: "products", path: "products/count" },
  { key: "enquiries", path: "enquiries/count" },
];
type Stat = { label: string; source: string; field: string; href?: string; total?: boolean };
const stats: Stat[] = [
  {label:"Today Seller Members",source:"sellers",field:"addedToday"},
  {label:"Today Buyer Members",source:"buyers",field:"addedToday"},
  {label:"Total Seller Members",source:"sellers",field:"total",total:true,href:"/admin/sellers"},
  {label:"Active Seller Members",source:"sellers",field:"statusActive",href:"/admin/sellers"},
  {label:"Inactive Seller Members",source:"sellers",field:"statusInactive",href:"/admin/inactive_sellers"},
  {label:"Not Approved Seller Members",source:"sellers",field:"notApproved",href:"/admin/not_approved_sellers"},
  {label:"Not Complete Seller",source:"sellers",field:"notCompleted",href:"/admin/not_completed_sellers"},
  {label:"Total Buyer Members",source:"buyers",field:"total",total:true,href:"/admin/buyers"},
  {label:"Active Buyer Members",source:"buyers",field:"statusActive",href:"/admin/buyers"},
  {label:"Inactive Buyer Members",source:"buyers",field:"statusInactive",href:"/admin/inactive_buyers"},
  {label:"Not Approved Buyer Members",source:"buyers",field:"notApproved",href:"/admin/not_approved_buyers"},
  {label:"Total Category",source:"categories",field:"total",href:"/admin/product_categories"},
  {label:"Total Sub Category",source:"subCategories",field:"total",href:"/admin/product_sub_categories"},
  {label:"Item Category",source:"itemCategories",field:"total",href:"/admin/item_category"},
  {label:"Item Sub Category",source:"itemSubCategories",field:"total",href:"/admin/item_sub_category"},
  {label:"Items",source:"items",field:"total",href:"/admin/new_items"},
  {label:"Total Products",source:"products",field:"total",href:"/admin/products"},
  {label:"Total Public Products",source:"products",field:"statusPublic",href:"/admin/approve-product-list"},
  {label:"Total Draft Products",source:"products",field:"statusDraft",href:"/admin/notapprove-product-list"},
  {label:"Enquiries Generated",source:"enquiries",field:"total",href:"/admin/enquiries-list"},
  {label:"Product added this month",source:"products",field:"addedThisMonth"},
];
const totalFields = ["statusActive","statusInactive","notApproved","notCompleted","deleted"];
function valueFor(stat:Stat, data:Record<string,Counts>):number|undefined {
  const item=data[stat.source]; if(!item) return undefined;
  if(stat.total && (stat.source==="sellers" || stat.source==="buyers")) return totalFields.reduce((sum,key)=>sum+(Number(item[key])||0),0);
  const value=item[stat.field]; return typeof value==="number"?value:undefined;
}
export default function AdminDashboard(){
  const [data,setData]=useState<Record<string,Counts>>({});
  const [errors,setErrors]=useState<string[]>([]);
  const [loading,setLoading]=useState(true);
  useEffect(()=>{
    let active=true;
    Promise.allSettled(endpoints.map(async entry=>({key:entry.key,data:await apiFetch<Counts>(entry.path)})))
      .then(results=>{if(!active)return;const next:Record<string,Counts>={};const failed:string[]=[];
        results.forEach((result,index)=>{if(result.status==="fulfilled")next[result.value.key]=result.value.data;else failed.push(endpoints[index].path);});
        setData(next);setErrors(failed);setLoading(false);
      });return()=>{active=false};
  },[]);
  return <div className="page-wrapper"><div className="page-content">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}><h1 style={{fontSize:24,margin:0}}>Dashboard</h1><span style={{color:"#64748b",fontSize:13}}>Admin overview</span></div>
    {errors.length>0&&<p role="alert" style={{background:"#fff3e5",padding:12,borderRadius:6}}>Some live statistics could not be loaded: {errors.join(", ")}. Missing values are shown as —.</p>}
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(225px,1fr))",gap:16}}>
      {stats.map((stat,index)=>{const value=valueFor(stat,data);const content=<div className={styles.card} style={{minHeight:115,position:"relative",overflow:"hidden",padding:20}}><p style={{fontSize:13,color:"#64748b",margin:"0 0 10px"}}>{stat.label}</p><strong style={{fontSize:27,color:"#25324b"}}>{loading?"…":value??"—"}</strong><span aria-hidden="true" style={{position:"absolute",right:18,top:22,width:38,height:38,borderRadius:"50%",background:["#e9f1ff","#e8f7ee","#f3eaff","#fff3e4"][index%4]}} /></div>;
        return stat.href?<Link key={stat.label} href={stat.href} style={{textDecoration:"none"}}>{content}</Link>:<div key={stat.label}>{content}</div>;
      })}
    </div>
    <section style={{marginTop:30}}><h2 style={{fontSize:18}}>Additional dashboard sections</h2><div className={styles.card}><p className={styles.muted}>Seller Graph, Buyer Graph, Leads Graph, Leads List, Registered Sellers/Buyers and Category Master export are pending migration. Statistics above use the existing live APIs.</p></div></section>
  </div></div>;
}
