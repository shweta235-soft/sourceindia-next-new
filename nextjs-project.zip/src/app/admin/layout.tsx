import AdminShell from "@/components/admin/AdminShell";

// AdminShell is mounted only here, not in the root layout or admin pages.
export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AdminShell>{children}</AdminShell>;
}
