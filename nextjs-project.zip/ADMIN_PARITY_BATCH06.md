Source-driven Admin shell changes:
- Replaced placeholder S branding with original frontend/public/logo.png.
- Mapped navigation icons from original React Sidebar.jsx menuData.
- Replaced incorrect Admin Login dropdown action with React-equivalent Logout (clears token).
- Original React ZIP was read-only.
- Not yet pixel-perfect or browser-verified; seller/buyer tables and API shortcut dropdown still need conversion.
