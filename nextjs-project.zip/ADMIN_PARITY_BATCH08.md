# Batch 08 — Admin navigation corrections

Reference inspected: original React `frontend/src/admin/common/Header.jsx`, `Sidebar.jsx` and `layouts/AdminLayout.jsx`.

Changes:
- Sidebar accordion uses explicit expansion state, keeping the active section expanded while allowing user navigation.
- Removed/deleted buyer and seller aliases now highlight the correct original React menu entries.
- Shortcut links limited to local admin paths; original React shortcut data still comes from the existing API.
- Compact sidebar markers, active state, scrollbars, dropdown height and mobile shadow refined.

This is **not** a pixel-perfect UI conversion. Original React DataTable, Header and Sidebar full JSX/CSS port and visual browser QA remain pending. No backend or database modifications.
