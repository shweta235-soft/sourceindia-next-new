Admin UI batch 04: Sellers filter grid and table CSS aligned to original React SellerList structure. UI-only, no API changes. React source read-only. Exact parity and build not yet verified.
