param(
  [string]$Target = "E:\nextjs\sourceindia-next-new"
)

$ErrorActionPreference = "Stop"
$bundle = [IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path)).TrimEnd('\')
$targetFull = [IO.Path]::GetFullPath($Target).TrimEnd('\')

if (-not (Test-Path -LiteralPath (Join-Path $bundle "src\app\layout.tsx"))) {
  throw "Repair package is incomplete: src\app\layout.tsx not found."
}
if (-not (Test-Path -LiteralPath (Join-Path $bundle "src\app\page.tsx"))) {
  throw "Repair package is incomplete: src\app\page.tsx not found."
}
if (-not (Test-Path -LiteralPath $targetFull -PathType Container)) {
  throw "Next.js target folder not found: $targetFull"
}
if ($bundle.Equals($targetFull, [StringComparison]::OrdinalIgnoreCase) -or
    $bundle.StartsWith($targetFull + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw "Extract this ZIP OUTSIDE the Next.js target folder, e.g. E:\nextjs\sourceindia-batch13-repair, and run this script from there."
}
if (-not (Test-Path -LiteralPath (Join-Path $targetFull "package.json"))) {
  throw "Target does not contain package.json; check the project path."
}

$parent = Split-Path -Parent $targetFull
$backup = Join-Path $parent ("sourceindia-next-new-repair-backup-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Path $backup | Out-Null

Write-Host "Backup folder: $backup"
Write-Host "Stop npm run dev / npm run build before continuing." -ForegroundColor Yellow

# Old source and route directories are MOVED outside the project so stale
# route-group layouts/pages cannot remain after ZIP extraction.
foreach ($name in @("src", "app", "pages", "public")) {
  $old = Join-Path $targetFull $name
  if (Test-Path -LiteralPath $old) {
    Move-Item -LiteralPath $old -Destination (Join-Path $backup $name)
  }
}

# Preserve previous project configuration for rollback.
foreach ($name in @("package.json", "package-lock.json", "tsconfig.json", "next.config.ts", "next-env.d.ts")) {
  $old = Join-Path $targetFull $name
  if (Test-Path -LiteralPath $old) {
    Copy-Item -LiteralPath $old -Destination (Join-Path $backup $name) -Force
  }
}

# Copy the clean, internally consistent project source.
foreach ($name in @("src", "public")) {
  $from = Join-Path $bundle $name
  if (Test-Path -LiteralPath $from) {
    Copy-Item -LiteralPath $from -Destination (Join-Path $targetFull $name) -Recurse -Force
  }
}
foreach ($name in @("package.json", "package-lock.json", "tsconfig.json", "next.config.ts", "next-env.d.ts")) {
  $from = Join-Path $bundle $name
  if (Test-Path -LiteralPath $from) {
    Copy-Item -LiteralPath $from -Destination (Join-Path $targetFull $name) -Force
  }
}

# Keep .env.local, .git and node_modules untouched.
$cache = Join-Path $targetFull ".next"
if (Test-Path -LiteralPath $cache) {
  Remove-Item -LiteralPath $cache -Recurse -Force
}

$rootLayout = Get-Content -LiteralPath (Join-Path $targetFull "src\app\layout.tsx") -Raw
$home = Get-Content -LiteralPath (Join-Path $targetFull "src\app\page.tsx") -Raw
$adminLayout = Get-Content -LiteralPath (Join-Path $targetFull "src\app\admin\layout.tsx") -Raw
if (-not ($rootLayout.Contains("<html") -and $rootLayout.Contains("<body"))) {
  throw "Root layout check failed."
}
if (-not $home.Contains("<Homepage")) {
  throw "Home route check failed."
}
if (-not $adminLayout.Contains("<AdminShell")) {
  throw "Admin layout check failed."
}
Write-Host ""
Write-Host "Clean source installed successfully." -ForegroundColor Green
Write-Host "Old files backed up to: $backup"
Write-Host ".env.local, .git and node_modules were preserved."
Write-Host "Next: cd `"$targetFull`"; npm run build"
