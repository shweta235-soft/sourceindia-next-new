# Batch 16 — Visible action column

- Sellers and Buyers list tables now have a sticky right-side Action column while scrolling horizontally.
- Three-dot menus and their existing View Profile / Copy Email actions remain unchanged.
- No API, database, login, public site, or route changes.
- This is a UI usability increment; full visual parity and build still require browser verification.
