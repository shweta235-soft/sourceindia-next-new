# Step 40 — Product Detail Categories
- React API endpoints used: `categories?is_delete=0&status=1&limit=40`, `item_sub_category`.
- Restored conditional Browse Related Categories and Popular Categories sections with original CSS classes and filter URLs.
- Updated Related Products heading to React's Find Similar Products; carousel remains a grid and is not claimed as full parity.
- Promotional Similar Products banner, enquiry modal, reviews and exact visual parity remain pending.
- No DB or original React changes. Full Next.js build and browser testing pending.
