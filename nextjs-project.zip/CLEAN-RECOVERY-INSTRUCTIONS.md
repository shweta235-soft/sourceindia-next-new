# SourceIndia — Batch 13 Clean Recovery

This is a **complete Next.js source project** based on Batch 13 with the prerender safeguard. It is intended for a **clean extraction**, not for merging into an existing project folder.

## Why this is needed
The archive contains exactly one root layout (`src/app/layout.tsx`), with both `<html>` and `<body>`, one homepage (`src/app/page.tsx` -> `Homepage`), and one Admin shell (`src/app/admin/layout.tsx` -> `AdminShell`). If `/` shows the Admin Dashboard or `/admin` shows two headers/sidebars, the running local project does not match this clean tree or another development server is being viewed.

## Windows steps (no manual code edits)
1. Stop **all** Next.js development servers in VS Code terminals using Ctrl+C.
2. In File Explorer, open `E:\nextjs\` and rename `sourceindia-next-new` to `sourceindia-next-new-backup` (keep this backup; do not delete it).
3. Create a new, empty `E:\nextjs\sourceindia-next-new` folder and extract **this ZIP directly into that folder**. You should see `package.json`, `src`, and `public` immediately inside it; not a second nested project folder.
4. Copy **only** `.env.local` from `sourceindia-next-new-backup` into the new folder. Do not copy `src`, `app`, `.next`, `node_modules`, or old layout files.
5. In a new terminal inside the new project folder run `npm install`, then `npm run build`, then `npm run dev` (one dev server only).
6. At 100% browser zoom check `http://localhost:3000/` (Public Homepage) and `http://localhost:3000/admin` (Admin Dashboard). Also check `/admin/sellers` for one Admin Header and one Sidebar.

## Verification limits
The ZIP archive structure and required files were checked. An npm install/build could not be completed in the packaging environment because package downloads were unavailable. **Do not treat this package as build-tested or browser-tested.**

## If the problem remains
Send: (a) the exact address bar URL, (b) terminal startup output showing the port, and (c) a screenshot of the new project root in File Explorer showing `package.json` and `src`. Do not merge older ZIPs into this clean folder.
