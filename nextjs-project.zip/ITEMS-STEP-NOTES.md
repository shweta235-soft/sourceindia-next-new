# Items page migration

Added `/items/[slug]` using existing item grid layout and React API `/categories/items?slug=...&page=...&limit=8`. Original React source unchanged.

Build and browser testing not performed.
