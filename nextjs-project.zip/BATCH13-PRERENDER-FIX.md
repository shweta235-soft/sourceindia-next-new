Prerender safeguard: safe unauthenticated context default. Root AuthProvider unchanged. Build and auth behavior pending verification.
