Batch 02: React-inspired compact Admin sidebar hierarchy, icon alignment, grouped submenu indentation and active link styling. No backend changes. This is not full React parity. Build not verified.
