# Admin parity batch 07

Source reviewed: React `admin/common/Header.jsx`, `admin/common/Sidebar.jsx`, `layouts/AdminLayout.jsx`.

Changes: header shortcuts now request the original React endpoint `shortcut/shortcut_menus?status=1` via the existing live API adapter; original loading/empty states; search clear affordance; compact dropdown styling; mobile sidebar width consistency; menu selection recognizes original removed-buyer/seller route names.

Scope: Header and navigation refinements only. The search remains presentational, as in the original Header.jsx. Seller/Buyer tables and full sidebar parity remain pending. Build and browser screenshot parity are not claimed.
