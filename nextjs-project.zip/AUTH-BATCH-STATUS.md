# Login + Registration batch

Added /login and /registration pages with original React's Bootstrap layout structure and live API calls.

Important: This is a first integration build, NOT an exact React parity signoff. The registration phone country picker is currently a +91 input rather than React's react-phone-input-2, pincode autofill is not migrated, and original React registration's full validation and redirect flow still need parity review. Login OTP resend cooldown is not implemented. The current frontend build could not be verified because npm installation timed out in this environment; run `npm install` if necessary, then `npm run build` in the target directory. Do not mark either page PASS until UI and API testing.

React source was used read-only; the prior enquiry ZIP was the base for this archive.
