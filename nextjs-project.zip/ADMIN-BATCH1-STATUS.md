# Admin Batch 1 — Navigation foundation (partial)

- Source: original React `frontend/src/admin/common/Sidebar.jsx` (read-only).
- Added Next.js admin shell with responsive sidebar, header, and links copied from the React sidebar.
- Added `/admin` dashboard placeholder; dashboard charts, count APIs, and login are NOT implemented.
- Menu links for pages not yet migrated will 404. Do not treat them as finished.
- This shell is not an authentication boundary. Do not deploy it as a secured admin dashboard.
- No React source or database changes.
- Build has not been run in this environment.
