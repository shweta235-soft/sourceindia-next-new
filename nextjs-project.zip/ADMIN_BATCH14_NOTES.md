# Batch 14 — Buyers listing UI alignment

Compared original React `BuyerList.jsx` DataTable columns and row markup with Next.js `MemberListing.tsx`.

- Replaced generic Buyers table with original-style column structure: selection, S.No., Company, Location, User/Account Status, Make Seller (where applicable), User Category, Created, Last Update, Action.
- Added company/contact stacked details, Trader and Walk-In Buyer badges, row selection, profile links, status indicators.
- Status indicators are **display only**; no unauthorized mutation endpoints or fake action menus were added.
- Existing Sellers advanced filters, public homepage, AdminShell and live API fetches preserved.
- Original React source ZIP was not modified.

**Not yet complete:** React BuyerModals, sourcing interests modal, full Excel export, and exact browser-based visual parity. The UI relies on field names from the existing API and needs runtime data verification.

**Validation:** ZIP integrity verified; npm build/browser verification pending.
