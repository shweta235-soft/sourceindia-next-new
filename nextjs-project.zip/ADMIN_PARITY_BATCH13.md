# Batch 13 — React seller filter lookups
Replaced disabled seller filter selects with live API-backed options following original SellerList.jsx lookup paths. Added dependent activity and city loading, preserved existing listing query. Build not verified.
